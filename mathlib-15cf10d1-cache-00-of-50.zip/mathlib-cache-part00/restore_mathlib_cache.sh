#!/usr/bin/env bash
# restore_mathlib_cache.sh -- rebuild ~/.cache/mathlib (Mathlib 15cf10d19dfd4cdee9602318e271fa3ce99c454d, 9,116 .ltar files)
# from the 50 data zips mathlib-15cf10d1-cache-NN-of-50.zip plus part 00 (this script, README, checksums).
# Usage: bash restore_mathlib_cache.sh [DIR_WITH_ZIPS] [CACHE_PARENT]     (defaults: . and $HOME/.cache)
set -euo pipefail
SRC="${1:-.}"; DEST="${2:-$HOME/.cache}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for i in $(seq -w 1 50); do
  [ -f "$SRC/mathlib-15cf10d1-cache-$i-of-50.zip" ] || { echo "missing $SRC/mathlib-15cf10d1-cache-$i-of-50.zip"; exit 1; }
done
mkdir -p "$DEST"
for i in $(seq -w 1 50); do unzip -o -q "$SRC/mathlib-15cf10d1-cache-$i-of-50.zip" -d "$DEST"; done
(cd "$DEST/mathlib" && sha256sum -c --quiet "$HERE/SHA256SUMS-ltar.txt")
echo "OK: $(ls "$DEST/mathlib" | wc -l) cache files in $DEST/mathlib"
echo "next: cd <project with Mathlib pinned to 15cf10d1> && lake exe cache get && lake build"
